import os
# Désactiver le message d'accueil de pygame
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import random
import tkinter as tk
from tkinter import ttk
import pygame
from mutagen.mp3 import MP3  # Sert à obtenir la durée du fichier mp3
import sys
import ctypes

# Dossier contenant les sons
dossier_sons = "oiseaux"
sons = [f for f in os.listdir(dossier_sons) if f.endswith(".mp3")]
sons_affichés = [os.path.splitext(f)[0] for f in sons]  # Pour affichage sans .mp3

class BlindTestApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Blind-Test Oiseaux")
        self.root.geometry("700x550")  # Fenêtre plus grande
        self.root.option_add("*Font", "Impact 12")  # Changer la police globale
        self.current_sound = None
        self.playing = False
        self.paused = False
        self.duration = 1
        self.animation_index = 0
        self.emoji_sequence = ["🕊️", "🐦", "🐤", "🦜"]

        # Emoji animé (affiché pendant la lecture)
        self.emoji_label = tk.Label(root, text="")
        self.emoji_label.pack()

        # Bouton pour jouer un son aléatoire (nouvelle couleur)
        self.play_button = tk.Button(root, text="🎵 Jouer un son aléatoire", command=self.play_random_sound, width=25, height=2, bg="#9C27B0", fg="white")
        self.play_button.pack(pady=10)

        # Contrôles du son
        controls = tk.Frame(root)
        controls.pack()
        tk.Button(controls, text="⏮️ Rejouer", command=self.replay, width=10, height=2, bg="#2196F3", fg="white").pack(side=tk.LEFT, padx=5)
        self.pause_button = tk.Button(controls, text="⏸️ Pause", command=self.toggle_pause, width=24, height=2, bg="#f44336", fg="white")
        self.pause_button.pack(side=tk.LEFT, padx=5)

        # Menu déroulant pour choisir le nom (décalé vers le bas)
        self.choix = tk.StringVar()
        self.dropdown = ttk.Combobox(root, textvariable=self.choix, values=sons_affichés, state="readonly", width=60)
        self.dropdown.pack(pady=25, ipady=4)
        self.dropdown.configure(height=20)

        # Bouton pour valider (décalé vers le bas)
        self.validate_button = tk.Button(root, text="✅ Valider", command=self.validate, width=25, height=2, bg="#FF9800", fg="white")
        self.validate_button.pack(pady=20)
        self.validate_button["state"] = "disabled"

        # Label résultat
        self.result = tk.Label(root, text="", font=("Helvetica", 14, "bold"))
        self.result.pack(pady=5)

        self.animate_emoji()

    def play_random_sound(self):
        self.stop()
        self.current_sound = random.choice(sons)
        full_path = os.path.join(dossier_sons, self.current_sound)
        audio = MP3(full_path)
        self.duration = int(audio.info.length)
        pygame.mixer.music.load(full_path)
        pygame.mixer.music.play()
        self.result.config(text="")
        self.choix.set("")
        self.validate_button["state"] = "normal"
        self.playing = True
        self.paused = False
        self.pause_button.config(text="⏸️ Pause", bg="#f44336")

    def replay(self):
        if self.current_sound:
            full_path = os.path.join(dossier_sons, self.current_sound)
            pygame.mixer.music.load(full_path)
            pygame.mixer.music.play()
            self.playing = True
            self.paused = False
            self.pause_button.config(text="⏸️ Pause", bg="#f44336")

    def stop(self):
        pygame.mixer.music.stop()
        self.emoji_label.config(text="")
        self.playing = False
        self.paused = False
        self.pause_button.config(text="⏸️ Pause", bg="#f44336")

    def toggle_pause(self):
        if self.playing:
            if self.paused:
                pygame.mixer.music.unpause()
                self.pause_button.config(text="⏸️ Pause", bg="#f44336")
                self.paused = False
            else:
                pygame.mixer.music.pause()
                self.pause_button.config(text="▶️ Reprendre", bg="#4CAF50")
                self.paused = True

    def validate(self):
        nom_sans_ext = os.path.splitext(self.current_sound)[0]
        if self.choix.get() == nom_sans_ext:
            self.result.config(text="✔️ Bonne réponse !", fg="green")
        else:
            self.result.config(text=f"❌ Mauvais choix !\nC'était : {nom_sans_ext}", fg="red")
        self.validate_button["state"] = "disabled"
        self.emoji_label.config(text="")

    def animate_emoji(self):
        if self.playing and not self.paused:
            emoji = self.emoji_sequence[self.animation_index % len(self.emoji_sequence)]
            self.emoji_label.config(text=emoji + " 🎶")
            self.animation_index += 1
        self.root.after(400, self.animate_emoji)


if __name__ == "__main__":
    if sys.platform == "win32":
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(u"BlindTestOiseaux")
    root = tk.Tk()
    root.iconbitmap("oiseau.ico")

    # Initialisation de pygame
    pygame.mixer.init()

    app = BlindTestApp(root)
    root.mainloop()
